package com.example.ultimavez.model;

public enum UserEnum {
    CUSTOMER,
    SELLER
}
