package com.example.ultimavez.activity;

import androidx.appcompat.app.AppCompatActivity;

public class SellerHomePageActivity extends AppCompatActivity {
}
