package com.example.ultimavez.activity;

import androidx.appcompat.app.AppCompatActivity;

public class CustomerHomePageActivity extends AppCompatActivity {
}
