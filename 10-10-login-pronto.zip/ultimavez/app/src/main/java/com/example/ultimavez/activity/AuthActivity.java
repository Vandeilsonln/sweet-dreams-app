package com.example.ultimavez.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import com.example.ultimavez.R;
import com.example.ultimavez.fragment.ErrorInflator;
import com.example.ultimavez.fragment.SuccessFragment;
import com.example.ultimavez.helper.Result;
import com.example.ultimavez.model.LoginDTO;
import com.example.ultimavez.model.User;
import com.example.ultimavez.model.UserEnum;
import com.example.ultimavez.service.LoginService;

public class AuthActivity extends AppCompatActivity {

    private Button btnAcessar, btnCadastro, btnRedefinirSenha;
    private EditText campoEmail, camposenha;
    private Switch tipoAcesso;
    private final LoginService loginService = new LoginService(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        getSupportActionBar().hide();

        inicializarComponentes();

        btnAcessar.setOnClickListener(it -> realizarLogin());
        btnCadastro.setOnClickListener(view -> abrirCadastro());
        btnRedefinirSenha.setOnClickListener(view -> abrirRedefinirSenha());
    }

    private void realizarLogin() {
        LoginDTO loginDTO = new LoginDTO(
                campoEmail.getText().toString(),
                camposenha.getText().toString(),
                tipoAcesso.isChecked() ? UserEnum.SELLER : UserEnum.CUSTOMER);

        Result<User> result = loginService.login(loginDTO);

        if (!result.isValid()) {
            ErrorInflator.showErrors(result.getNotifications(), this);
        } else {
            Intent intent = new Intent(AuthActivity.this, defineHomePage(result.getResultObject().getType()));
            startActivity(intent);
        }
    }

    private Class<? extends AppCompatActivity> defineHomePage(UserEnum userType) {
        return userType == UserEnum.SELLER ? SellerHomePageActivity.class : CustomerHomePageActivity.class;
    }

    private void inicializarComponentes() {
        campoEmail = findViewById(R.id.txtEmail);
        camposenha = findViewById(R.id.txtPassword);
        btnCadastro = findViewById(R.id.btnSignup);
        btnAcessar = findViewById(R.id.btnLogin);
        tipoAcesso = findViewById(R.id.switchAcesso);
        btnRedefinirSenha = findViewById(R.id.btnForgotPassword);
    }

    private void abrirCadastro() {
        Intent intent = new Intent(AuthActivity.this, SignUpActivity.class);
        startActivity(intent);
    }

    public void abrirRedefinirSenha() {
        Intent intent = new Intent(AuthActivity.this, RedefinePasswordActivity.class);
        startActivity(intent);
    }
}