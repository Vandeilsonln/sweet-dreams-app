package com.example.ultimavez.service;

import com.example.ultimavez.helper.Result;
import com.example.ultimavez.model.User;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

public class UserValidatorService {

    private static final String CPF_REGEX = "\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}";
    private static final String ZIP_CODE_REGEX = "\\d{5}-\\d{3}";
    private static final String PHONE_NUMBER_REGEX = "\\(\\d{2}\\)\\d{5}-\\d{4}";
    private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@(.+)$";

    public Result<User> validateUser(User user) {
        Result<User> result = new Result<>(user);

        verifyNullValues(user, result);
        verifyMasks(user, result);

        return result;
    }

    private void verifyNullValues(User user, Result<User> result) {
        if (isEmpty(user.getEmail())) {
            result.addNotification("Email é obrigatório");
        }

        if (isEmpty(user.getPassword())) {
            result.addNotification("Senha é obrigatório");
        }

        if (isEmpty(user.getFullName())) {
            result.addNotification("Nome completo é obrigatório");
        }

        if (isEmpty(user.getDocument())) {
            result.addNotification("Documento é obrigatório");
        }

        if (isEmpty(user.getAddress())) {
            result.addNotification("Endereço é obrigatório");
        }

        if (isEmpty(user.getCity())) {
            result.addNotification("Cidade é obrigatório");
        }

        if (isEmpty(user.getZipCode())) {
            result.addNotification("CEP é obrigatório");
        }

        if (isEmpty(user.getPhoneNumber())) {
            result.addNotification("Telefone é obrigatório");
        }
    }

    private boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    private void verifyMasks(User user, Result<User> result) {
        if (invalidPattern(user.getDocument(), CPF_REGEX)) {
            result.addNotification("CPF inválido");
        }

        if (invalidPattern(user.getPhoneNumber(), PHONE_NUMBER_REGEX)) {
            result.addNotification("Telefone inválido");
        }

        if (invalidPattern(user.getZipCode(), ZIP_CODE_REGEX)) {
            result.addNotification("CEP inválido");
        }

        if (invalidPattern(user.getEmail(), EMAIL_REGEX)) {
            result.addNotification("E-mail inválido");
        }
    }

    private boolean invalidPattern(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return !matcher.matches();
    }
}
