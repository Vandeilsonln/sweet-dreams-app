package com.example.ultimavez.model;

import org.hibernate.validator.constraints.br.CPF;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public class User {

    private long id;
    private UserEnum type;

    @Email(message = "Formato de email inválido")
    private String email;

    @NotNull
    @Size(min = 8, message = "Senha deve ter no mínimo 8 caracteres")
    private String password;

    @NotNull(message = "Nome não pode estar em branco")
    private String fullName;

    @CPF(message = "CPF inválido")
    private String document;

    @NotNull
    @Pattern(regexp = "^\\(\\d{2}\\)\\d{5}-\\d{4}$", message = "Telefone inválido")
    private String phoneNumber;

    @NotNull(message = "Endereço não pode estar em branco")
    private String address;

    @Pattern(regexp = "^\\d{5}-\\d{3}$", message = "CEP inválido")
    private String zipCode;

    @NotNull(message = "Cidade não pode estar em branco")
    private String city;

    public User(UserEnum type, String email, String password, String fullName, String document, String phoneNumber, String address, String zipCode, String city) {
        this.type = type;
        this.email = email;
        this.password = password;
        this.fullName = fullName;
        this.document = document;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.zipCode = zipCode;
        this.city = city;
    }

    public long getId() {
        return id;
    }

    public UserEnum getType() {
        return type;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getFullName() {
        return fullName;
    }

    public String getDocument() {
        return document;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public String getZipCode() {
        return zipCode;
    }

    public String getCity() {
        return city;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
