package com.example.ultimavez.service;

import android.content.Context;

import com.example.ultimavez.helper.PasswordEncrypter;
import com.example.ultimavez.helper.Result;
import com.example.ultimavez.model.LoginDTO;
import com.example.ultimavez.model.User;
import com.example.ultimavez.persistence.UserPersistence;
import com.example.ultimavez.persistence.sqlite.UserTableHelper;

import java.util.Optional;

public class LoginService {

    private final UserPersistence database;

    public LoginService(Context context) {
        this.database = new UserTableHelper(context);
    }

    public Result<User> login(LoginDTO loginDTO) {
        Result<User> result = new Result<>(null);

        Optional<User> user = database.findByEmailAndType(loginDTO.getEmail(), loginDTO.getUserType());
        if (!user.isPresent()) {
            result.addNotification("Usuário não encontrado");
            return result;
        }

        if (!PasswordEncrypter.validatePassword(loginDTO.getPassword(), user.get().getPassword())) {
            result.addNotification("Senha incorreta");
        }

        result.setResultObject(user.get());
        return result;
    }
}
