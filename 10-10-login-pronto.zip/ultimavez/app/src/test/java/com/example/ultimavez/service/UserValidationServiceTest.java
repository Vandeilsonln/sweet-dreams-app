package com.example.ultimavez.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.example.ultimavez.helper.Result;
import com.example.ultimavez.model.User;
import com.example.ultimavez.model.UserEnum;
import org.junit.Test;

public class UserValidationServiceTest {

    private final UserValidatorService validatorService = new UserValidatorService();
    private User testUser;

    @Test
    public void userWithMissingDataShouldHaveErrorInValidation() {
        testUser = new User(UserEnum.CUSTOMER, "", "", "", "", "", "", "", "");
        Result<User> result = validatorService.validateUser(testUser);

        assertEquals(12, result.getNotifications().size());
    }

    @Test
    public void userWithInvalidCPFShouldReturnError() {
        testUser = new User(UserEnum.CUSTOMER, "email@email.com", "12345678", "Fulano da Silva", "12345678909", "(11)98765-4321", "Rua da Vitória", "09876-543", "São Bernardo do Campo");
        Result<User> result = validatorService.validateUser(testUser);

        assertEquals(1, result.getNotifications().size());
        assertEquals("CPF inválido", result.getNotifications().get(0));
    }

    @Test
    public void userWithInvalidPhoneNumberShouldReturnError() {
        testUser = new User(UserEnum.CUSTOMER, "email@email.com", "12345678", "Fulano da Silva", "123.456.789-09", "11987654321", "Rua da Vitória", "09876-543", "São Bernardo do Campo");
        Result<User> result = validatorService.validateUser(testUser);

        assertEquals(1, result.getNotifications().size());
        assertEquals("Telefone inválido", result.getNotifications().get(0));
    }

    @Test
    public void userWithInvalidZipCodeShouldReturnError() {
        testUser = new User(UserEnum.CUSTOMER, "email@email.com", "12345678", "Fulano da Silva", "123.456.789-09", "(11)98765-4321", "Rua da Vitória", "09876543", "São Bernardo do Campo");
        Result<User> result = validatorService.validateUser(testUser);

        assertEquals(1, result.getNotifications().size());
        assertEquals("CEP inválido", result.getNotifications().get(0));
    }

    @Test
    public void userWithInvalidEmailShouldReturnError() {
        testUser = new User(UserEnum.CUSTOMER, "emailemail.com", "12345678", "Fulano da Silva", "123.456.789-09", "(11)98765-4321", "Rua da Vitória", "09876-543", "São Bernardo do Campo");
        Result<User> result = validatorService.validateUser(testUser);

        assertEquals(1, result.getNotifications().size());
        assertEquals("E-mail inválido", result.getNotifications().get(0));
    }

    @Test
    public void validUserShouldReturnSuccess() {
        testUser = new User(UserEnum.CUSTOMER, "emai@lemail.com", "12345678", "Fulano da Silva", "123.456.789-09", "(11)98765-4321", "Rua da Vitória", "09876-543", "São Bernardo do Campo");
        Result<User> result = validatorService.validateUser(testUser);

        assertTrue(result.getNotifications().isEmpty());
    }

}
