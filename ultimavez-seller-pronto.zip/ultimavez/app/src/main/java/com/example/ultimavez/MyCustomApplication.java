package com.example.ultimavez;

import android.app.Application;

import com.example.ultimavez.persistence.ProductPersistence;
import com.example.ultimavez.persistence.UserPersistence;
import com.example.ultimavez.persistence.sqlite.ProductTableHelper;
import com.example.ultimavez.persistence.sqlite.UserTableHelper;

public class MyCustomApplication extends Application {

    private static UserPersistence userTableHelper;
    private static ProductPersistence productTableHelper;
    public static final int DATABASE_VERSION = 12;

    @Override
    public void onCreate() {
        super.onCreate();

        userTableHelper = new UserTableHelper(this);
        productTableHelper = new ProductTableHelper(this);
    }

    public static UserPersistence getUserPersistence() {
        return userTableHelper;
    }
    public static ProductPersistence getProductPersistence() {
        return productTableHelper;
    }

}
