package com.example.ultimavez.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.ultimavez.R;

public class CustomerHomePageActivity extends AppCompatActivity {

    private CardView cPremium, cGourmet, cVegano, cEspeciais, cEncomendar, cPedidos, cHistoria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_home_page);
        getSupportActionBar().hide();

        inicializarComponentes();

    }

    private void inicializarComponentes() {
        cPremium = findViewById(R.id.cardPremium);
        cGourmet = findViewById(R.id.cardGourmet);
        cVegano = findViewById(R.id.cardVegano);
        cEspeciais = findViewById(R.id.cardEspeciais);
        cEncomendar = findViewById(R.id.cardEncomenda);
        cPedidos = findViewById(R.id.cardPedidos);
        cHistoria = findViewById(R.id.cardOurHistory);
    }

}
