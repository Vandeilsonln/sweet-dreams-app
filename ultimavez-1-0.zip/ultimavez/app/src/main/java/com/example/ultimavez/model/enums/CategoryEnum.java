package com.example.ultimavez.model.enums;

public enum CategoryEnum {
    PREMIUM,
    GOURMET,
    VEGANO,
    ESPECIAIS
}
