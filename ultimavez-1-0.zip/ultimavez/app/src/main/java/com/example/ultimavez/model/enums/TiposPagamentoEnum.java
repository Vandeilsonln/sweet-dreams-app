package com.example.ultimavez.model.enums;

public enum TiposPagamentoEnum {
    PIX,
    CREDITO
}
