package com.example.ultimavez.model.enums;

public enum PedidoStatusEnum {
    PENDENTE_PAGAMENTO,
    CONFIRMADO,
    CANCELADO;
}
