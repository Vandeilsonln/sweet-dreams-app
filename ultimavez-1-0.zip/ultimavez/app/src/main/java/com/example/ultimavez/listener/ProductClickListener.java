package com.example.ultimavez.listener;

import com.example.ultimavez.model.domain.Product;

public interface ProductClickListener {
    void onProductClick(Product product);
}
