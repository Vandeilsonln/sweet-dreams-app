package com.example.ultimavez.model.enums;

public enum UserEnum {
    CUSTOMER,
    SELLER
}
