package com.example.ultimavez.persistence;

import static com.example.ultimavez.helper.UserTableHelper.COLUMN_ADDRESS;
import static com.example.ultimavez.helper.UserTableHelper.COLUMN_DOCUMENT;
import static com.example.ultimavez.helper.UserTableHelper.COLUMN_EMAIL;
import static com.example.ultimavez.helper.UserTableHelper.COLUMN_FULLNAME;
import static com.example.ultimavez.helper.UserTableHelper.COLUMN_PASSWORD;
import static com.example.ultimavez.helper.UserTableHelper.COLUMN_PHONENUMBER;
import static com.example.ultimavez.helper.UserTableHelper.COLUMN_TYPE;
import static com.example.ultimavez.helper.UserTableHelper.TABLE_NAME;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.ultimavez.UserValidator;
import com.example.ultimavez.helper.PasswordEncrypter;
import com.example.ultimavez.helper.Result;
import com.example.ultimavez.helper.UserTableHelper;
import com.example.ultimavez.model.User;

import org.mindrot.jbcrypt.BCrypt;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class UserPersistenceSqLite implements UserPersistence{

    private UserValidator validator = new UserValidator();
    private UserTableHelper database;

    public UserPersistenceSqLite(Context context) {
        database = new UserTableHelper(context);
    }

    @Override
    public Result<User> saveUser(User user) {
        Result<User> validationResult =  validator.validateUser(user);

        if (!validationResult.isValid()) {
            return Result.invalid(validationResult.getNotifications());
        }

        long dbResult = insertIntoDb(user);
        if (dbErrorHasHappened(dbResult)) {
            return Result.invalid("Ocorreu um problema interno. Tente novamente mais tarde");
        }

        return Result.valid(user);
    }

    private long insertIntoDb(User user) {
        SQLiteDatabase db = database.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_TYPE, user.getType().toString());
        contentValues.put(COLUMN_FULLNAME, user.getFullName());
        contentValues.put(COLUMN_EMAIL, user.getEmail());
        contentValues.put(COLUMN_PASSWORD, encryptPassword(user.getPassword()));
        contentValues.put(COLUMN_ADDRESS, user.getAddress());
        contentValues.put(COLUMN_PHONENUMBER, user.getPhoneNumber());
        contentValues.put(COLUMN_DOCUMENT, user.getDocument());

        return db.insert(TABLE_NAME, null, contentValues);
    }

    private boolean dbErrorHasHappened(long dbResult) {
        return dbResult == -1;
    }

    private String encryptPassword(String password) {
        return PasswordEncrypter.encryptPassword(password);
    }

}
