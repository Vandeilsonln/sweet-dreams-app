package com.example.ultimavez.helper;

import java.util.ArrayList;
import java.util.List;

public class Result<T> {
    private final List<String> notifications = new ArrayList<>();
    private final T resultObject;

    public Result(T resultObject) {
        this.resultObject = resultObject;
    }

    public static <T> Result<T> valid(T resultObject) {
        return new Result<>(resultObject);
    }

    public static <T> Result<T> invalid(List<String> notifications) {
        Result<T> validationResult = new Result<>(null);
        validationResult.addNotification(notifications);
        return validationResult;
    }

    public static <T> Result<T> invalid(String notification) {
        Result<T> validationResult = new Result<>(null);
        validationResult.addNotification(notification);
        return validationResult;
    }

    public boolean isValid() {
        return notifications.isEmpty();
    }

    public List<String> getNotifications() {
        return new ArrayList<>(notifications);
    }

    public T getResultObject() {
        return resultObject;
    }

    public void addNotification(String notification) {
        notifications.add(notification);
    }

    public void addNotification(List<String> notification) {
        notifications.addAll(notification);
    }
}

