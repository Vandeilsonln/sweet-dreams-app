package com.example.ultimavez.activity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ultimavez.R;
import com.example.ultimavez.fragment.SuccessFragment;
import com.example.ultimavez.helper.Result;
import com.example.ultimavez.model.User;
import com.example.ultimavez.model.UserEnum;
import com.example.ultimavez.persistence.UserPersistence;
import com.example.ultimavez.persistence.UserPersistenceSqLite;

import java.util.List;

public class SignUpActivity extends AppCompatActivity {

    private EditText txtEmail, txtPassword, txtFullName, txtCpf, txtPhone, txtAddress, txtZipCode, txtCity;
    private Button btnSignup;
    private Switch userTypeSwitch;

    private final UserPersistence persistence = new UserPersistenceSqLite(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();

        initComponents();

        btnSignup.setOnClickListener(it -> saveUser());

    }

    @Override
    public void onBackPressed() {
        finish();
    }

    private void initComponents() {
        txtEmail = findViewById(R.id.txtEmail);
        txtPassword = findViewById(R.id.txtPassword);
        txtFullName = findViewById(R.id.txtFullName);
        txtCpf = findViewById(R.id.txtCpf);
        txtPhone = findViewById(R.id.txtPhone);
        txtAddress = findViewById(R.id.txtAddress);
        txtZipCode = findViewById(R.id.txtZipCode);
        txtCity = findViewById(R.id.txtCity);
        btnSignup = findViewById(R.id.btnSign);
        userTypeSwitch = findViewById(R.id.switchAcesso);
    }

    private void saveUser() {
        User user = buildUserFromInput();
        Result<User> result = persistence.saveUser(user);

        if (!result.isValid()) {
            showErrors(result.getNotifications());
        } else {
            showSuccess();
        }
    }

    @NonNull
    private User buildUserFromInput() {
        String email = txtEmail.getText().toString();
        String password = txtPassword.getText().toString();
        String fullName = txtFullName.getText().toString();
        String cpf = txtCpf.getText().toString();
        String phone = txtPhone.getText().toString();
        String address = txtAddress.getText().toString();
        String zipCode = txtZipCode.getText().toString();
        String city = txtCity.getText().toString();
        UserEnum userType = userTypeSwitch.isChecked() ? UserEnum.SELLER : UserEnum.CUSTOMER;

        return new User(userType, email,password,fullName, cpf, phone, address, zipCode, city);
    }

    private void showErrors(List<String> notifications) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.sign_up_error, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        ListView errorMessages = dialogView.findViewById(R.id.errorMessages);
        Button okButton = dialogView.findViewById(R.id.okButton);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notifications);
        errorMessages.setAdapter(adapter);

        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);

        okButton.setOnClickListener(view -> dialog.dismiss());

        dialog.show();
    }

    private void showSuccess() {
        SuccessFragment successDialog = new SuccessFragment("Cadastro realizado com sucesso");
        successDialog.show(getSupportFragmentManager(), null);
    }
}
