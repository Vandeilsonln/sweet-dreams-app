package com.example.ultimavez.helper;

import org.mindrot.jbcrypt.BCrypt;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class PasswordEncrypter {

    public static String encryptPassword(String password) {
        byte[] hashedPasswordInBytes = BCrypt.hashpw(password, BCrypt.gensalt()).getBytes(StandardCharsets.UTF_8);
        return UUID.nameUUIDFromBytes(hashedPasswordInBytes).toString();
    }

    public static boolean validatePassword(String plainTextPassword, String hashedPassword) {
        return BCrypt.checkpw(encryptPassword(plainTextPassword), hashedPassword);
    }
}
