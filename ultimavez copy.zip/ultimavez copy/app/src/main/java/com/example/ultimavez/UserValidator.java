package com.example.ultimavez;

import com.example.ultimavez.helper.Result;
import com.example.ultimavez.model.User;

public class UserValidator {

    public Result<User> validateUser(User user) {
        Result<User> result = new Result(user);

        // Validações

        return result;
    }
}
