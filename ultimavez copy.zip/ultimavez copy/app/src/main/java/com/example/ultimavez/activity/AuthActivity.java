package com.example.ultimavez.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import com.example.ultimavez.R;

public class AuthActivity extends AppCompatActivity {

    private Button btnAcessar, btnCadastro;
    private EditText campoEmail, camposenha;
    private Switch tipoAcesso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        getSupportActionBar().hide();

        inicializarComponentes();

        btnCadastro.setOnClickListener(view -> abrirCadastro());
    }

    private void inicializarComponentes() {
        campoEmail = findViewById(R.id.txtEmail);
        camposenha = findViewById(R.id.txtPassword);
        btnCadastro = findViewById(R.id.btnSignup);
        btnAcessar = findViewById(R.id.btnLogin);
        tipoAcesso = findViewById(R.id.switchAcesso);
    }

    private void abrirCadastro() {
        Intent intent = new Intent(AuthActivity.this, SignUpActivity.class);
        startActivity(intent);
    }
}